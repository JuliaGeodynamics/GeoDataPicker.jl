%FACTORIZE:  an object-oriented method for solving linear systems and least
% squares problems.  The method provides an efficient way of computing
