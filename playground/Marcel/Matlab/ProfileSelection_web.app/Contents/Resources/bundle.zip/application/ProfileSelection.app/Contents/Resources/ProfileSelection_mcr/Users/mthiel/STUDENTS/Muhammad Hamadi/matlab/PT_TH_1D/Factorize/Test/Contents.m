% Test code for the FACTORIZE object.
%
